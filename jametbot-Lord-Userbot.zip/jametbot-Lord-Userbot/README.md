<a href="https://cooltext.com"><img src="https://images.cooltext.com/5501763.gif" width="473" height="82" alt="LORD USERBOT" /></a>


<p align="center">
  <a href="https://github.com/Zora24/Lord-Userbot/fork">
    <img src="https://img.shields.io/github/forks/Zora24/Lord-Userbot?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/Zora24/Lord-Userbot">
    <img src="https://img.shields.io/github/stars/Zora24/Lord-Userbot?style=social">
  </a>
</p>  

# Lord Userbot
![Lord Userbot Logo](https://telegra.ph/file/62dc59b2013a48f9cc8f3.jpg)

<h3 align="center">Userbot Yang Digunakan Untuk Bersenang-Senang Di Telegram</h3>
<p align="center">&nbsp;</p>

### Repo Lord Userbot
Repo Yang Dibuat [Alvin](https://t.me/liualvinas) Dari Berbagai Repo Userbot Github 


### CARA MENDAPATKAN STRING SESSON

Caranya Pergi Ke Grup Support Lord-Userbot Lalu Ketik #String [TEKAN DISINI](https://t.me/LordUserbot_Group) Untuk Masuk Ke Grup Support

## Bagaimana Cara Deploy?

```
* **CARA DEPLOY** 🔧

  > Pertama Dapatkan API_KE & API_HASH Di my.telegram.org (Wajib)

  > Dapatkan String Session Di Termux (Wajib)

  > Next Tekan Tombol Deploy Dibawah

  > Isi Datanya Lalu Tekan Deploy Lagi

  > Terakhir Hidupkan Dyno Lalu Check Logs (settings -> view logs) Jika Berhasil Enjoy :)
```
Atau Bisa Gabung Ke Grup Lord Userbot -> [TEKAN DISINI](https://t.me/LordUserbot_Group)
## <p align="center">DEPLOY LORD-USERBOT</p>


<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Zora24/Lord-Userbot/tree/Lord-Userbot"> <img src="https://img.shields.io/badge/Deploy%20Ke%20Heroku-magenta?style=flat&logo=heroku" width="210" height="34.45" /></a></p>

<br>
</p>

## Credit
TERIMAKASIH UNTUK

*   [RaphielGang](https://github.com/RaphielGang) - Telegram-Paperplane
*   [AvinashReddy3108](https://github.com/AvinashReddy3108) - PaperplaneExtended
*   [Mkaraniya](https://github.com/mkaraniya) & [Dev73](https://github.com/Devp73) - OpenUserBot
*   [Mr.Miss](https://github.com/keselekpermen69) - UserButt
*   [adekmaulana](https://github.com/adekmaulana) - ProjectBish
*   [MoveAngel](https://github.com/MoveAngel) - One4uBot
*   [AidilAryanto](https://github.com/aidilaryanto) - ProjectDils 
*   [Alfianandaa](https://github.com/alfianandaa/ProjectAlf) - ProjectAlf
*   [AnggaR69s](https://github.com/GengKapak/DCLXVI) - DCLXVI
*   [kandnub](https://github.com/kandnub) - TG-UserBot
*   [༺αиυвιѕ༻](https://github.com/Dark-Princ3) - X-tra-Telegram
*   [Sahyam2019](https://github.com/sahyam2019/oub-remix) - oub-remix
*   [TeamUserge](https://github.com/UsergeTeam/Userge) - Userge
*   DAN BANYAK LAGI 
